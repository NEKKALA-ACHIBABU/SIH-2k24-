from django.apps import AppConfig


class ExpertDashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'expert_dashboard'
